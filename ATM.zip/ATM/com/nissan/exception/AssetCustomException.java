package com.nissan.exception;

@SuppressWarnings("serial")
public class AssetCustomException extends Exception{
	
	public AssetCustomException(String message) {
		super(message);
	}
}
